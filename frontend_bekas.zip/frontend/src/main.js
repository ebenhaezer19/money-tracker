import { createApp } from 'vue'
import { createPinia } from 'pinia'
import App from './App.vue'
import router from './router'
import { useAuthStore } from './stores/auth'

// Buat instance aplikasi Vue
const app = createApp(App)

// Pasang Pinia
const pinia = createPinia()
app.use(pinia)

// Pasang router
app.use(router)

// Initialize auth state
const authStore = useAuthStore()
authStore.initAuth()

// Mount aplikasi
app.mount('#app') 