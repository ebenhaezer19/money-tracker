<script>
import { useAuthStore } from '../stores/auth'
import { useRouter } from 'vue-router'

export default {
  setup() {
    const authStore = useAuthStore()
    const router = useRouter()

    const handleLogin = async (credentials) => {
      try {
        await authStore.login(credentials)
        // Redirect ke workspace setelah login berhasil
        router.push('/workspace')
      } catch (error) {
        console.error('Login error:', error)
      }
    }

    return {
      handleLogin
    }
  }
}
</script> 