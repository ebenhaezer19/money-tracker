<template>
  <div class="workspace">
    <header class="workspace-header">
      <h1>Money Tracker Workspace</h1>
      <div class="user-info">
        <span>{{ user?.username }}</span>
      </div>
    </header>

    <main class="workspace-content">
      <div class="categories">
        <h2>Categories</h2>
        <div class="category-list">
          <!-- Category items will go here -->
        </div>
      </div>

      <div class="transactions">
        <h2>Transactions</h2>
        <div class="transaction-controls">
          <button @click="openNewTransactionForm" class="btn-new">
            New Transaction
          </button>
        </div>
        <div class="transaction-list">
          <!-- Transaction items will go here -->
        </div>
      </div>
    </main>
  </div>
</template>

<script>
import { useAuthStore } from '../stores/auth'

export default {
  name: 'Workspace',
  
  setup() {
    const authStore = useAuthStore()
    
    return {
      user: authStore.user
    }
  },

  methods: {
    openNewTransactionForm() {
      // Will implement later
      console.log('Opening new transaction form...')
    }
  }
}
</script>

<style scoped>
.workspace {
  padding: 20px;
}

.workspace-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 30px;
}

.workspace-header h1 {
  color: #2c3e50;
  margin: 0;
}

.user-info {
  background: #f8f9fa;
  padding: 8px 16px;
  border-radius: 4px;
}

.workspace-content {
  display: grid;
  grid-template-columns: 300px 1fr;
  gap: 30px;
}

.categories, .transactions {
  background: white;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

h2 {
  color: #2c3e50;
  margin-top: 0;
  margin-bottom: 20px;
}

.btn-new {
  background: #4CAF50;
  color: white;
  border: none;
  padding: 8px 16px;
  border-radius: 4px;
  cursor: pointer;
  font-weight: 500;
}

.btn-new:hover {
  background: #45a049;
}

.transaction-controls {
  margin-bottom: 20px;
}

@media (max-width: 768px) {
  .workspace-content {
    grid-template-columns: 1fr;
  }
}
</style>